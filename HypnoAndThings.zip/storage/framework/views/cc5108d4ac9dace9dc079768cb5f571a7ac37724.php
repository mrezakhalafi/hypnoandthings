<div>
    <h1 style="color: #6C5840"><?php echo e($data['title']); ?></h1>
</div>

<div style="margin-top: 20px">
    Berikut merupakan data customer yang telah mendaftar pada website.
    <br>
    <br>

    <b>Nama : </b> <?php echo e($data['nama_lengkap']); ?><br>
    <b>Email : </b> <?php echo e($data['email']); ?><br>
    <b>Status : </b> <?php echo e($data['status']); ?><br>
    <b>Nama panggilan : </b> <?php echo e($data['nama_panggilan']); ?><br>
    <b>Telepon : </b> <?php echo e($data['telepon']); ?><br>
    <br>
    <b>Jenis kelamin : </b> <?php echo e($data['jenis_kelamin']); ?><br>
    <b>Agama : </b> <?php echo e($data['agama']); ?><br>
    <b>Alamat : </b> <?php echo e($data['alamat']); ?><br>
    <b>Kota : </b> <?php echo e($data['kota']); ?><br>
    <b>Provinsi : </b> <?php echo e($data['provinsi']); ?><br>
    <br>
    <b>Mengetahui dari : </b>
    <?php if($data['mengetahui_dari[]']!=null): ?>
    <?php $__currentLoopData = $data['mengetahui_dari[]']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($a.","); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <br>
    <b>Mengikuti atas : </b>
    <?php if($data['mengetahui_dari[]']!=null): ?>
    <?php $__currentLoopData = $data['mengikuti_atas[]']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($b.","); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <br>
    <b>Hubungan orang tua : </b>
    <?php if($data['hubungan_orangtua[]']!=null): ?>
    <?php $__currentLoopData = $data['hubungan_orangtua[]']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($c.","); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <br>
    <b>Alasan mengikuti : </b> <?php echo e($data['alasan_mengikuti']); ?><br>
    <b>Dalam penanganan : </b> <?php echo e($data['dalam_penanganan']); ?><br>
    <br>
    <b>Orang tua mengalami : </b> <?php echo e($data['orangtua_mengalami']); ?><br>
    <b>Yakin selesai : </b> <?php echo e($data['yakin_selesai']); ?><br>
    <b>Pernah berkonsultasi : </b>
    <?php if($data['pernah_berkonsultasi[]']!=null): ?>
    <?php $__currentLoopData = $data['pernah_berkonsultasi[]']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($d.","); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <br>
    <b>Pernah hipnoterapi : </b> <?php echo e($data['pernah_hipnoterapi']); ?><br>
    <b>Perasaan dirasakan : </b>
    <?php if($data['perasaan_dirasakan[]']!=null): ?>
    <?php $__currentLoopData = $data['perasaan_dirasakan[]']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($e.","); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <br>
    <br>
    <b>Kondisi kesehatan : </b>
    <?php if($data['kondisi_kesehatan[]']!=null): ?>
    <?php $__currentLoopData = $data['kondisi_kesehatan[]']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($f.","); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <br>
    <b>Mengalami gangguan : </b>
    <?php if($data['mengalami_gangguan[]']!=null): ?>
    <?php $__currentLoopData = $data['mengalami_gangguan[]']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($g.","); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <br>
    <b>Perubahan diharapkan : </b> <?php echo e($data['perubahan_diharapkan']); ?><br>
    <h1 style="margin-top: 20px; color: #6C5840"><b>Jadwal sesi : <?php echo e($data['jadwal_sesi']); ?></b></h1>
</div>
 <?php /**PATH C:\xampp\htdocs\HypnoAndThings\resources\views/emailku.blade.php ENDPATH**/ ?>